A Pen created at CodePen.io. You can find this one at http://codepen.io/j-w-v/pen/vxwJB.

 Playing with a login form layout. 